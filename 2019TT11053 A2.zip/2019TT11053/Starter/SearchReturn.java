
public class SearchReturn {
Node a;
Hnode b;
public Node getA() {
	return a;
}
public void setA(Node a) {
	this.a = a;
}
public Hnode getB() {
	return b;
}
public void setB(Hnode b) {
	this.b = b;
}
public SearchReturn(Node a,Hnode b)
{
	this.a=a;
	this.b=b;
	
	
}

}
