// Tree is Empty
public class EmptyTreeException extends Exception{  
    EmptyTreeException(String s){  
        super(s);  
    }  
}

